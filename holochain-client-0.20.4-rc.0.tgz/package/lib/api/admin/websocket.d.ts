import { CapSecret, GrantedFunctions } from "../../hdk/index.js";
import type { AgentPubKey, CellId } from "../../types.js";
import { WsClient } from "../client.js";
import { Requester, Transformer, WebsocketConnectionOptions } from "../common.js";
import { AddAgentInfoRequest, AddAgentInfoResponse, AdminApi, AgentInfoRequest, AgentInfoResponse, PeerMetaInfoResponse, PeerMetaInfoRequest, AttachAppInterfaceRequest, AttachAppInterfaceResponse, DeleteCloneCellRequest, DeleteCloneCellResponse, DisableAppRequest, DisableAppResponse, DumpFullStateRequest, DumpFullStateResponse, DumpNetworkMetricsRequest, DumpNetworkMetricsResponse, DumpNetworkStatsRequest, DumpNetworkStatsResponse, DumpStateRequest, DumpStateResponse, EnableAppRequest, EnableAppResponse, GenerateAgentPubKeyRequest, GenerateAgentPubKeyResponse, GetDnaDefinitionRequest, GetDnaDefinitionResponse, GrantZomeCallCapabilityRequest, GrantZomeCallCapabilityResponse, InstallAppRequest, InstallAppResponse, IssueAppAuthenticationTokenRequest, IssueAppAuthenticationTokenResponse, ListAppInterfacesRequest, ListAppInterfacesResponse, ListAppsRequest, ListAppsResponse, ListCellIdsRequest, ListCellIdsResponse, ListDnasRequest, ListDnasResponse, RevokeZomeCallCapabilityRequest, RevokeZomeCallCapabilityResponse, RevokeAgentKeyRequest, RevokeAgentKeyResponse, StorageInfoRequest, StorageInfoResponse, UninstallAppRequest, UninstallAppResponse, UpdateCoordinatorsRequest, UpdateCoordinatorsResponse, ListCapabilityGrantsRequest, ListCapabilityGrantsResponse } from "./types.js";
/**
 * A class for interacting with a conductor's Admin API.
 *
 * @public
 */
export declare class AdminWebsocket implements AdminApi {
    /**
     * The websocket client used for transporting requests and responses.
     */
    readonly client: WsClient;
    /**
     * Default timeout for any request made over the websocket.
     */
    defaultTimeout: number;
    private constructor();
    /**
     * Factory mehtod to create a new instance connected to the given URL.
     *
     * @param options - {@link (WebsocketConnectionOptions:interface)}
     * @returns A promise for a new connected instance.
     */
    static connect(options?: WebsocketConnectionOptions): Promise<AdminWebsocket>;
    _requester<ReqI, ReqO, ResI, ResO>(tag: string, transformer?: Transformer<ReqI, ReqO, ResI, ResO>): (req: ReqI, timeout?: number) => Promise<ResO>;
    /**
     * Send a request to open the given port for {@link AppWebsocket} connections.
     */
    attachAppInterface: Requester<AttachAppInterfaceRequest, AttachAppInterfaceResponse>;
    /**
     * Enable a stopped app.
     */
    enableApp: Requester<EnableAppRequest, EnableAppResponse>;
    /**
     * Disable a running app.
     */
    disableApp: Requester<DisableAppRequest, DisableAppResponse>;
    /**
     * Dump the state of the specified cell, including its source chain, as JSON.
     */
    dumpState: Requester<DumpStateRequest, DumpStateResponse>;
    /**
     * Dump the full state of the specified cell, including its chain and DHT
     * shard, as JSON.
     */
    dumpFullState: Requester<DumpFullStateRequest, DumpFullStateResponse>;
    /**
     * Generate a new agent pub key.
     */
    generateAgentPubKey: Requester<GenerateAgentPubKeyRequest, GenerateAgentPubKeyResponse>;
    /**
     * Generate a new agent pub key.
     */
    revokeAgentKey: Requester<RevokeAgentKeyRequest, RevokeAgentKeyResponse>;
    /**
     * Get the DNA definition for the specified DNA hash.
     */
    getDnaDefinition: Requester<GetDnaDefinitionRequest, GetDnaDefinitionResponse>;
    /**
     * Uninstall the specified app from Holochain.
     */
    uninstallApp: Requester<UninstallAppRequest, UninstallAppResponse>;
    /**
     * Install the specified app into Holochain.
     */
    installApp: Requester<InstallAppRequest, InstallAppResponse>;
    /**
     * Update coordinators for an installed app.
     */
    updateCoordinators: Requester<UpdateCoordinatorsRequest, UpdateCoordinatorsResponse>;
    /**
     * List all registered DNAs.
     */
    listDnas: Requester<ListDnasRequest, ListDnasResponse>;
    /**
     * List all installed cell ids.
     */
    listCellIds: Requester<ListCellIdsRequest, ListCellIdsResponse>;
    /**
     * List all installed apps.
     */
    listApps: Requester<ListAppsRequest, ListAppsResponse>;
    /**
     * List all attached app interfaces.
     */
    listAppInterfaces: Requester<ListAppInterfacesRequest, ListAppInterfacesResponse>;
    /**
     * Request all available info about an agent.
     */
    agentInfo: Requester<AgentInfoRequest, AgentInfoResponse>;
    /**
     * Add an existing agent to Holochain.
     */
    addAgentInfo: Requester<AddAgentInfoRequest, AddAgentInfoResponse>;
    /**
     * Request peer meta info for a peer.
     */
    peerMetaInfo: Requester<PeerMetaInfoRequest, PeerMetaInfoResponse>;
    /**
     * Delete a disabled clone cell.
     */
    deleteCloneCell: Requester<DeleteCloneCellRequest, DeleteCloneCellResponse>;
    /**
     * Grant a zome call capability for an agent, to be used for signing zome
     * calls.
     */
    grantZomeCallCapability: Requester<GrantZomeCallCapabilityRequest, GrantZomeCallCapabilityResponse>;
    /**
     * Revoke a zome call capability for an agent, which was previously granted
     * using {@link AdminWebsocket.grantZomeCallCapability}.
     */
    revokeZomeCallCapability: Requester<RevokeZomeCallCapabilityRequest, RevokeZomeCallCapabilityResponse>;
    /**
     * List all capability grants for all cells.
     */
    listCapabilityGrants: Requester<ListCapabilityGrantsRequest, ListCapabilityGrantsResponse>;
    storageInfo: Requester<StorageInfoRequest, StorageInfoResponse>;
    issueAppAuthenticationToken: Requester<IssueAppAuthenticationTokenRequest, IssueAppAuthenticationTokenResponse>;
    dumpNetworkStats: Requester<DumpNetworkStatsRequest, DumpNetworkStatsResponse>;
    dumpNetworkMetrics: Requester<DumpNetworkMetricsRequest, DumpNetworkMetricsResponse>;
    /**
     * Grant a capability for signing zome calls.
     *
     * @param cellId - The cell to grant the capability for.
     * @param functions - The zome functions to grant the capability for.
     * @param signingKey - The assignee of the capability.
     * @returns The cap secret of the created capability.
     */
    grantSigningKey: (cellId: CellId, functions: GrantedFunctions, signingKey: AgentPubKey) => Promise<CapSecret>;
    /**
     * Generate and authorize a new key pair for signing zome calls.
     *
     * @param cellId - The cell id to create the capability grant for.
     * @param functions - Zomes and functions to authorize the signing key for
     * (optional). When no functions are specified, the capability will be
     * granted for all zomes and functions.
     */
    authorizeSigningCredentials: (cellId: CellId, functions?: GrantedFunctions) => Promise<void>;
}
