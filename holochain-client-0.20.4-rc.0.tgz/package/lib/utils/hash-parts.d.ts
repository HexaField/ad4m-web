import { HoloHash, HoloHashType } from "../types.js";
/**
 * Hash type labels mapped to their 3 byte values (forming the first 3 bytes of hash).
 *
 * From https://github.com/holochain/holochain/blob/develop/crates/holo_hash/src/hash_type/primitive.rs
 *
 * @public
 */
export declare const HASH_TYPE_PREFIX: {
    agent: Uint8Array<ArrayBuffer>;
    entry: Uint8Array<ArrayBuffer>;
    dhtop: Uint8Array<ArrayBuffer>;
    warrant: Uint8Array<ArrayBuffer>;
    dna: Uint8Array<ArrayBuffer>;
    action: Uint8Array<ArrayBuffer>;
    wasm: Uint8Array<ArrayBuffer>;
    external: Uint8Array<ArrayBuffer>;
};
/**
 * Get hash type (initial 3 bytes) from a hash.
 *
 * From https://github.com/holochain/holochain/blob/develop/crates/holo_hash/src/hash_type/primitive.rs
 *
 * @param hash - The full 39 byte hash.
 * @returns The initial 3 bytes of the hash.
 *
 * @public
 */
export declare function sliceHashType(hash: HoloHash): Uint8Array;
/**
 * Get core hash from a Holochain hash (32 bytes).
 *
 * From https://github.com/holochain/holochain/blob/develop/crates/holo_hash/src/hash_type/primitive.rs
 *
 * @param hash - The full 39 byte hash.
 * @returns The core 32 bytes of the hash.
 *
 * @public
 */
export declare function sliceCore32(hash: HoloHash): Uint8Array;
/**
 * Get DHT location (last 4 bytes) from a hash.
 *
 * From https://github.com/holochain/holochain/blob/develop/crates/holo_hash/src/hash_type/primitive.rs
 *
 * @param hash - The full 39 byte hash.
 * @returns The last 4 bytes of the hash.
 *
 * @public
 */
export declare function sliceDhtLocation(hash: HoloHash): Uint8Array;
/**
 * Generate DHT location (last 4 bytes) from a core hash (middle 32 bytes).
 *
 * From https://github.com/holochain/holochain/blob/develop/crates/holo_hash/src/hash_type/primitive.rs
 *
 * @param hashCore - The core 32 bytes of the hash.
 * @returns The last 4 bytes of the hash.
 *
 * @public
 */
export declare function dhtLocationFrom32(hashCore: Uint8Array): Uint8Array;
/**
 * Get hash type of a hash, by reading the first 3 bytes.
 *
 * From https://github.com/holochain/holochain/blob/develop/crates/holo_hash/src/hash_type/primitive.rs
 *
 * @param hash - The full 39 byte hash.
 * @returns The HashType
 *
 * @public
 */
export declare function getHashType(hash: HoloHash): HoloHashType;
/**
 * Generate full hash from a core hash (middle 32 bytes) and hash type label.
 *
 * From https://github.com/holochain/holochain/blob/develop/crates/holo_hash/src/hash_type/primitive.rs
 *
 * @param hashCore - The core 32 bytes of the hash.
 * @param hashType - The type of the hash.
 * @returns The full 39 byte hash.
 *
 * @public
 */
export declare function hashFrom32AndType(hashCore: HoloHash, hashType: HoloHashType): Uint8Array;
/**
 * Generate full hash from some data content and hash type label.
 *
 * From https://github.com/holochain/holochain/blob/develop/crates/holo_hash/src/hash_type/primitive.rs
 *
 * @param content - The data to hash.
 * @param hashType - The type of the hash.
 * @returns The full 39 byte hash.
 *
 * @public
 */
export declare function hashFromContentAndType(content: any, hashType: HoloHashType): Uint8Array;
