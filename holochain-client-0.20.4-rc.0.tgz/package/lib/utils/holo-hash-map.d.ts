import { ActionHash, ActionHashB64, AgentPubKey, AgentPubKeyB64, AnyDhtHash, AnyDhtHashB64, DhtOpHash, DhtOpHashB64, DnaHash, DnaHashB64, EntryHash, EntryHashB64, ExternalHash, ExternalHashB64, HoloHash, HoloHashB64, WarrantHash, WarrantHashB64, WasmHash, WasmHashB64 } from "../types.js";
/**
 * A Map of HoloHashB64 to a value.
 *
 * @param initialEntries - Optional array of [key, value] pairs to insert into the map.
 *
 * @public
 */
export declare class HoloHashB64Map<K extends HoloHashB64, V> extends Map<K, V> {
    constructor(initialEntries?: Array<[K, V]>);
}
/**
 * @public
 */
export declare class AgentPubKeyB64Map<V> extends HoloHashB64Map<AgentPubKeyB64, V> {
}
/**
 * @public
 */
export declare class DnaHashB64Map<V> extends HoloHashB64Map<DnaHashB64, V> {
}
/**
 * @public
 */
export declare class WasmHashB64Map<V> extends HoloHashB64Map<WasmHashB64, V> {
}
/**
 * @public
 */
export declare class EntryHashB64Map<V> extends HoloHashB64Map<EntryHashB64, V> {
}
/**
 * @public
 */
export declare class ActionHashB64Map<V> extends HoloHashB64Map<ActionHashB64, V> {
}
/**
 * @public
 */
export declare class AnyDhtHashB64Map<V> extends HoloHashB64Map<AnyDhtHashB64, V> {
}
/**
 * @public
 */
export declare class ExternalHashB64Map<V> extends HoloHashB64Map<ExternalHashB64, V> {
}
/**
 * @public
 */
export declare class DhtOpHashB64Map<V> extends HoloHashB64Map<DhtOpHashB64, V> {
}
/**
 * @public
 */
export declare class WarrantHashB64Map<V> extends HoloHashB64Map<WarrantHashB64, V> {
}
/**
 * A Map of HoloHash to a value.
 *
 * @param initialEntries - Optional array of [key, value] pairs to insert into the map.
 *
 * @public
 */
export declare class HoloHashMap<K extends HoloHash, V> implements Map<K, V> {
    private _map;
    constructor(initialEntries?: Array<[K, V]>);
    /**
     * Removes all entries from the map.
     */
    clear(): void;
    /**
     * Returns an iterator of values in the map.
     *
     * @returns An iterator of all values
     */
    values(): MapIterator<V>;
    /**
     * Checks if a key exists in the map.
     *
     * @param key - The HoloHash key to check
     * @returns True if the key exists, false otherwise
     */
    has(key: K): boolean;
    /**
     * Gets the value associated with a key.
     *
     * @param key - The HoloHash key
     * @returns The value if found, undefined otherwise
     */
    get(key: K): V | undefined;
    /**
     * Sets a key-value pair in the map.
     *
     * @param key - The HoloHash key
     * @param value - The value to store
     * @returns This map instance for chaining
     */
    set(key: K, value: V): this;
    /**
     * Deletes an entry from the map.
     *
     * @param key - The HoloHash key to delete
     * @returns True if the entry was deleted, false if it didn't exist
     */
    delete(key: K): boolean;
    /**
     * Returns an iterator of keys in the map.
     *
     * @returns An iterator of all HoloHash keys
     */
    keys(): MapIterator<K>;
    /**
     * Returns an iterator of [key, value] pairs.
     *
     * @returns An iterator of all entries
     */
    entries(): MapIterator<[K, V]>;
    /**
     * Executes a callback function for each entry in the map.
     *
     * @param callbackfn - Function to execute for each entry
     * @param thisArg - Optional value to use as 'this' when executing the callback
     */
    forEach(callbackfn: (value: V, key: K, map: Map<K, V>) => void, thisArg?: any): void;
    [Symbol.iterator](): IterableIterator<[K, V]>;
    get [Symbol.toStringTag](): string;
    /**
     * The number of entries in the map.
     *
     * @returns The size of the map
     */
    get size(): number;
    private _encodeKey;
    private _decodeKey;
}
/**
 * @public
 */
export declare class AgentPubKeyMap<V> extends HoloHashMap<AgentPubKey, V> {
}
/**
 * @public
 */
export declare class DnaHashMap<V> extends HoloHashMap<DnaHash, V> {
}
/**
 * @public
 */
export declare class WasmHashMap<V> extends HoloHashMap<WasmHash, V> {
}
/**
 * @public
 */
export declare class EntryHashMap<V> extends HoloHashMap<EntryHash, V> {
}
/**
 * @public
 */
export declare class ActionHashMap<V> extends HoloHashMap<ActionHash, V> {
}
/**
 * @public
 */
export declare class AnyDhtHashMap<V> extends HoloHashMap<AnyDhtHash, V> {
}
/**
 * @public
 */
export declare class ExternalHashMap<V> extends HoloHashMap<ExternalHash, V> {
}
/**
 * @public
 */
export declare class DhtOpHashMap<V> extends HoloHashMap<DhtOpHash, V> {
}
/**
 * @public
 */
export declare class WarrantHashMap<V> extends HoloHashMap<WarrantHash, V> {
}
/**
 * A HoloHashMap that will fetch and store a value if it is not found in a 'get' call.
 *
 * @param fetchValue - A function that takes a key and fetches its value.
 * @param initialEntries - Optional array of [key, value] pairs to insert into the map.
 *
 * @public
 */
export declare class LazyHoloHashMap<K extends HoloHash, V> extends HoloHashMap<K, V> {
    protected fetchValue: (key: K) => V | undefined;
    constructor(fetchValue: (key: K) => V | undefined, initialEntries?: Array<[K, V]>);
    /**
     *
     * Get a value for a key.
     *
     * If no value for a key is found, it is fetched, inserted into the Map, then returned.
     *
     * @param key - HoloHash key
     * @returns value if found
     */
    get(key: K): V | undefined;
}
/**
 * @public
 */
export declare class LazyAgentPubKeyMap<V> extends LazyHoloHashMap<AgentPubKey, V> {
}
/**
 * @public
 */
export declare class LazyDnaHashMap<V> extends LazyHoloHashMap<DnaHash, V> {
}
/**
 * @public
 */
export declare class LazyWasmHashMap<V> extends LazyHoloHashMap<WasmHash, V> {
}
/**
 * @public
 */
export declare class LazyEntryHashMap<V> extends LazyHoloHashMap<EntryHash, V> {
}
/**
 * @public
 */
export declare class LazyActionHashMap<V> extends LazyHoloHashMap<ActionHash, V> {
}
/**
 * @public
 */
export declare class LazyAnyDhtHashMap<V> extends LazyHoloHashMap<AnyDhtHash, V> {
}
/**
 * @public
 */
export declare class LazyExternalHashMap<V> extends LazyHoloHashMap<ExternalHash, V> {
}
/**
 * @public
 */
export declare class LazyDhtOpHashMap<V> extends LazyHoloHashMap<DhtOpHash, V> {
}
/**
 * @public
 */
export declare class LazyWarrantHashMap<V> extends LazyHoloHashMap<WarrantHash, V> {
}
