import { HoloHash, DnaHash, ActionHash, AgentPubKey, AnyDhtHash, DhtOpHash, EntryHash, ExternalHash, WarrantHash, WasmHash } from "../types.js";
/**
 * A Map of DnaHash to HoloHashMap.
 *
 * i.e. A Map of DnaHash to a Map of HoloHash to a value.
 *
 * @param initialEntries - Optional array of `[[DnaHash, HoloHash], value]` to insert into the map.
 *
 * @public
 */
export declare class DnaHoloHashMap<K extends HoloHash, T> {
    private _dnaMap;
    constructor(initialEntries?: Array<[[DnaHash, K], T]>);
    /**
     * Gets the value associated with a [DnaHash, HoloHash] key pair.
     *
     * @param key - Array of [DnaHash, HoloHash]
     * @returns The value if found, undefined otherwise
     */
    get([dnaHash, key]: [DnaHash, K]): T | undefined;
    /**
     * Checks if a [DnaHash, HoloHash] key pair exists in the map.
     *
     * @param cellKey - Array of [DnaHash, HoloHash] to check
     * @returns True if the key exists, false otherwise
     */
    has([dnaHash, key]: [DnaHash, K]): boolean;
    /**
     * Sets a value for a [DnaHash, HoloHash] key pair.
     *
     * @param key - Tuple of [DnaHash, HoloHash]
     * @param value - The value to store
     * @returns This map instance for chaining
     */
    set([dnaHash, key]: [DnaHash, K], value: T): this;
    /**
     * Removes all entries from the map.
     */
    clear(): void;
    /**
     * Deletes an entry from the map. If this was the last entry for a DNA, the DNA entry is also removed.
     *
     * @param key - Array of [DnaHash, HoloHash] to delete
     * @returns True if the DNA entry was deleted (last entry for that DNA), false otherwise
     */
    delete([dnaHash, key]: [DnaHash, K]): boolean;
    /**
     * Returns all [DnaHash, HoloHash] key pairs in the map.
     *
     * @returns Array of all key tuples
     */
    keys(): Array<[DnaHash, K]>;
    /**
     * Returns all values in the map.
     *
     * @returns Array of all values
     */
    values(): Array<T>;
    /**
     * Returns all entries as [[DnaHash, HoloHash], value] Arrays.
     *
     * @returns Array of all entries
     */
    entries(): Array<[[DnaHash, K], T]>;
    /**
     * Creates a new DnaHoloHashMap containing only entries that match the filter predicate.
     *
     * @param fn - Predicate function to test each value
     * @returns A new filtered map
     */
    filter(fn: (value: T) => boolean): DnaHoloHashMap<K, T>;
    /**
     * Creates a new DnaHoloHashMap with values transformed by the mapping function.
     *
     * @param fn - Function to transform each value
     * @returns A new mapped map
     */
    map<R>(fn: (value: T) => R): DnaHoloHashMap<K, R>;
    /**
     * Returns all HoloHash keys for a specific DNA.
     *
     * @param dnaHash - The DNA hash to query
     * @returns Array of HoloHash keys for this DNA
     */
    keysForDna(dnaHash: DnaHash): Array<K>;
    /**
     * Returns all values for a specific DNA.
     *
     * @param dnaHash - The DNA hash to query
     * @returns Array of values for this DNA
     */
    valuesForDna(dnaHash: DnaHash): Array<T>;
    /**
     * Returns all [HoloHash, value] entries for a specific DNA.
     *
     * @param dnaHash - The DNA hash to query
     * @returns Array of entries for this DNA
     */
    entriesForDna(dnaHash: DnaHash): Array<[K, T]>;
    /**
     * Removes all entries for a specific DNA.
     *
     * @param dnaHash - The DNA hash to clear
     */
    clearForDna(dnaHash: DnaHash): void;
    /**
     * The number of DNA entries in the map.
     *
     * @returns The number of unique DNAs
     */
    get size(): number;
}
/**
 * @public
 */
export declare class DnaAgentPubKeyMap<V> extends DnaHoloHashMap<AgentPubKey, V> {
}
/**
 * @public
 */
export declare class DnaDnaHashMap<V> extends DnaHoloHashMap<DnaHash, V> {
}
/**
 * @public
 */
export declare class DnaWasmHashMap<V> extends DnaHoloHashMap<WasmHash, V> {
}
/**
 * @public
 */
export declare class DnaEntryHashMap<V> extends DnaHoloHashMap<EntryHash, V> {
}
/**
 * @public
 */
export declare class DnaActionHashMap<V> extends DnaHoloHashMap<ActionHash, V> {
}
/**
 * @public
 */
export declare class DnaAnyDhtHashMap<V> extends DnaHoloHashMap<AnyDhtHash, V> {
}
/**
 * @public
 */
export declare class DnaExternalHashMap<V> extends DnaHoloHashMap<ExternalHash, V> {
}
/**
 * @public
 */
export declare class DnaDhtOpHashMap<V> extends DnaHoloHashMap<DhtOpHash, V> {
}
/**
 * @public
 */
export declare class DnaWarrantHashMap<V> extends DnaHoloHashMap<WarrantHash, V> {
}
/**
 * @public
 */
export declare class CellMap<V> extends DnaAgentPubKeyMap<V> {
}
